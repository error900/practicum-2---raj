# practicum-2---raj
short term praticum 2 ( MACAM, Denmark S. | NAPADAO Karl Lester P.)

awan agradwar :D
