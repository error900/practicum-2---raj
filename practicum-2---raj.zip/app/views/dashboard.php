<div class="row">
	<div class="col-md-10 col-md-offset-1">
		<div class="dashboard">
			<!--
			<div ng-app="app">

				<div ng-controller="tabbed_pages">

					<tabset>

						<?php
						$user = Sentry::getUser();
						if ($user->isSuperUser())
							{
						?>

								<tab>

								<tab-heading>
									<span>I/O</span>
								</tab-heading>

								<div class="dashboard-inner">

								</div>
								
								</tab>

						<?php
							}
						?>

					</tabset>

				</div>

			</div>
			-->
		</div>
	</div>
</div>