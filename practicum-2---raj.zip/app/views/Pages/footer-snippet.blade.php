
        

    </div>
    <!-- /.container -->
    
        <!-- Footer -->
    <div class="container-fluid">
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p style="float: left;">Copyright &copy; RAJ. Technologies Inc. 2015</p>
                    <p style="float: right;"><a href="{{ URL::to('home') }}">Home</a> | <a href="{{ URL::to('about-us') }}">About</a> | <a href="{{ URL::to('services-page') }}">Services</a> | <a href="{{ URL::to('contact-page') }}">Contact</a> | <a href="{{ URL::to('career-page') }}">Careers</a> | <a href="{{ URL::to('dashboard') }}">Login</a></p>
                </div>
            </div>
        </footer>
    </div>

    <!-- jQuery -->
    <script src="{{ asset('Assets/js/jquery-1.11.2.min.js') }}"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{ asset('Assets/js/bootstrap.min.js') }}"></script>

	<!-- Custom JavaScript -->
	<script src="{{ asset('Assets/js/bootbox.min.js') }}"></script>
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=false"></script>
	<script src="{{ asset('Assets/js/scripts.js') }}"></script>
	