@extends(Config::get('syntara::views.master'))

@section('content')
@stop
