<?php
    return array(
        'public_key'=>'6Lcdcf8SAAAAAFYGXXKG_VyPS1GYRUNYbQy9bDGv',
        'private_key'=>'6Lcdcf8SAAAAAPrZZ2dqvKnKH3V6FQFrYogzW1c5'
    );
?>
