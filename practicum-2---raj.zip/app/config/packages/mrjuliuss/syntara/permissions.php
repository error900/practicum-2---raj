<?php 

return array(
        'listGroups' => 'groups-management',
        'newGroupPost' => 'groups-management',
        'newGroup' => 'groups-management',
        'deleteGroup' => 'groups-management',
        'showGroup' => 'groups-management',
        'putGroup' => 'groups-management',
        'listUsers' => 'view-users-list',
        'deleteUsers' => 'delete-user',
        'newUser' => 'create-user',
        'newUserPost' => 'create-user',
        'showUser' => 'update-user-info',
        'putUser' => 'update-user-info',
        'putActivateUser' => 'update-user-info',
        'deleteUserGroup' => 'user-group-management',
        'addUserGroup' => 'user-group-management',
        'listPermissions' => 'permissions-management',
        'deletePermission' => 'permissions-management',
        'newPermission' => 'permissions-management',
        'newPermissionPost' => 'permissions-management',
        'showPermission' => 'permissions-management',
        'putPermission' => 'permissions-management',
        'addUserPermission' => 'permissions-management',
        'addGroupPermission' => 'permissions-management'
);