angular.module('app', ['ui.bootstrap']);
angular.module('app').controller('tabbed_pages', function ($scope) {
});