
	function mouseOver1() {
	document.getElementById("image-icon1").src = "Assets/img/slider/Logo1-C.gif";
    document.getElementById("text-caption").innerHTML = "2-Way Radio Communication";
	}

	function mouseOut1() {
	document.getElementById("image-icon1").src = "Assets/img/slider/Logo1.gif";
    document.getElementById("text-caption").innerHTML = "";
	}
	
	/*=======================================================================*/
	
	function mouseOver2() {
	document.getElementById("image-icon2").src = "Assets/img/slider/Logo2-C.gif";
    document.getElementById("text-caption").innerHTML = "Imaging Solutions";
	}

	function mouseOut2() {
	document.getElementById("image-icon2").src = "Assets/img/slider/Logo2.gif";
    document.getElementById("text-caption").innerHTML = "";
	}
	
	/*=======================================================================*/
	
	function mouseOver3() {
	document.getElementById("image-icon3").src = "Assets/img/slider/Logo3-C.gif";
    document.getElementById("text-caption").innerHTML = "Information Technology (IT)";
	}

	function mouseOut3() {
	document.getElementById("image-icon3").src = "Assets/img/slider/Logo3.gif";
    document.getElementById("text-caption").innerHTML = "";
	}
	
	/*=======================================================================*/
	
	function mouseOver4() {
	document.getElementById("image-icon4").src = "Assets/img/slider/Logo4-C.gif";
    document.getElementById("text-caption").innerHTML = "Security & Surveillance";
	}

	function mouseOut4() {
	document.getElementById("image-icon4").src = "Assets/img/slider/Logo4.gif";
    document.getElementById("text-caption").innerHTML = "";
	}
	
	/*=======================================================================*/
	
	function mouseOver5() {
	document.getElementById("image-icon5").src = "Assets/img/slider/Logo5-C.gif";
    document.getElementById("text-caption").innerHTML = "Renewable Energy";
	}

	function mouseOut5() {
	document.getElementById("image-icon5").src = "Assets/img/slider/Logo5.gif";
    document.getElementById("text-caption").innerHTML = "";
	}